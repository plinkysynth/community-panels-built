MPE Surface presets for Plinky 12

1. Unzip the archive.
2. Copy the extracted PLINKY folder to the root of your Plinky's SD card and merge it with the existing PLINKY folder.
   The song banks belong in PLINKY/u_mpe_test/ on the card.
3. Open this panel's song picker to load a preset.

Back up any songs in the matching banks and slots before replacing files.
